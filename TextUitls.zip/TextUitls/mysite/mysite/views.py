# This file created by me

from django.http import HttpResponse
from django.shortcuts import render


def index(request):
    return render(request, 'index.html')


def analayze(request):
    djtext = request.POST.get('text', 'default')
    removefunc = request.POST.get('removefunc', 'off')
    capitalize = request.POST.get('capitalize', 'off')
    ExtraspaceRemover = request.POST.get('ExtraspaceRemover', 'off')
    NewlineRemover = request.POST.get('NewlineRemover', 'off')
    if removefunc == 'on':
        punctuations = '''!()-{}[];:'"/,<>.?@#$%#$%$^^'''
        analayzed = ""
        for char in djtext:
            if char not in punctuations:
                analayzed = analayzed + char
        params = {'purpose': 'Remove punctuations', 'analayze_text': analayzed}
        djtext = analayzed
        # return render(request, 'analayze.html', params)
    if capitalize == 'on':
        analayzed = ""
        for char in djtext:
            analayzed = analayzed + char.upper()
        params = {'purpose': 'text capitalize', 'analayze_text': analayzed}
        djtext = analayzed

    if ExtraspaceRemover == 'on':
        analayzed = ""
        for index, char in enumerate(djtext):
            if not (djtext[index] == " " and djtext[index + 1] == " "):
                analayzed = analayzed + char

        params = {'purpose': 'ExtraspaceRemover', 'analayze_text': analayzed}
        djtext = analayzed

    if NewlineRemover== 'on':
        analayzed = ""
        for char in djtext:
            if char != "\n" and char != "\r":
                analayzed = analayzed + char
        params = {'purpose': 'Newlineremover', 'analayze_text': analayzed}
        djtext = analayzed
    if removefunc != "on" and capitalize != "on" and ExtraspaceRemover != "on" and NewlineRemover != "on":
        return HttpResponse("Select any option to show your result")

    return render(request, 'analayze.html', params)


